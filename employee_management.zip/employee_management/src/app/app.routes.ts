import { Routes } from '@angular/router';
import { EmployeesComponent } from './employees/employees.component';
import { HomeComponent } from './home/home/home.component';
import { ContactComponent } from './employees/contact/contact/contact.component';
import { LoginComponent } from './employees/login/login.component';
import { DashboardComponent } from './employees/dashboard/dashboard.component';
import { LayoutComponent } from './employees/layout/layout.component';
import { Component } from '@angular/core';
import { ProjectEmployeeComponent } from './employees/project-employee/project-employee.component';
import { ProjectsComponent } from './employees/projects/projects.component';

export const routes: Routes = [
    
    {
        path:'',
        redirectTo:'login',
        pathMatch:'full'
    },
    {
        path:'login',
        component:LoginComponent
    },
    {
        path:'',
        component:LayoutComponent,
        children:[
            {
                path:'dashboard',
                component:DashboardComponent
            },
            {
                path:'employees',
                component:EmployeesComponent
            },
            {
                path:'projects',
                component:ProjectsComponent
            },
            {
                path:'project_employee',
                component:ProjectEmployeeComponent
            },

        ]
    }
]        