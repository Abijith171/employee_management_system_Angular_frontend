import { Component } from '@angular/core';

@Component({
  selector: 'app-project-employee',
  standalone: true,
  imports: [],
  templateUrl: './project-employee.component.html',
  styleUrl: './project-employee.component.css'
})
export class ProjectEmployeeComponent {

}
