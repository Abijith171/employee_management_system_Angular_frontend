export interface IEmployee {
    employee_id: number;
    name: string;
    email_id :string;
    contact: number;
    department: string ;
    role : string;
    actions : any;
}





